

let palabraAdivinar;
let cantidadErrores = 0; //Variable que cuenta los errores
let cantAciertos = 0; // Variable que cuenta los aciertos del juego
let totalIntentos = 7; // Cantidad de intentos que restaremos

const btnReiniciar = document.getElementById("reiniciar");//Obtenemos el elemento botón para reiniciar
const intentosJuego = document.getElementById("intentos"); //Span que permite ver los intentos del jugador.
const canvas = document.getElementById("dibujarCanva"); //Elemento el cual tiene el espacio para dibujar el canva
const context = canvas.getContext("2d");// Contexto que maneja el canva 


//Vector de palabras para el juego
const palabras = [
    'CAFETERA', /* 0*/
    'CARAMELOS', /* 1*/
    'DISCIPLINA', /* 2*/
    'ESTUDIO',   /* 3*/
    'PROGRAMACION', /* 4*/
    'STREAMER', /* 5*/
    'CAMISETA',   /* 6*/
    'CALISTENIA', /* 7*/
    'ELEFANTE', /* 8*/
    'AVION', /* 9*/
    'JARDIN', /* 10*/
    'COCODRILO', /* 11*/
    'GUITARRA' /* 12*/
  ];


const imagen = id('imagen');
//Guardamos en la variable todos los botones de letras.
const btn_letras = document.querySelectorAll("#letras button");

//Dibujamos la base de la horca para el personaje.
dibujarPoste();

/* Iniciamos el juego con el siguiente método */
iniciar();

//Agregamos función al botón de reiniciar.
btnReiniciar.addEventListener('click', function () {
  // Reload lo utilizamos para recargar el sitio.
  location.reload();
});


//Función para dibujar el poste inicial

function dibujarPoste(){
  context.clearRect(0, 0, canvas.width, canvas.height);

  // Restaurar el color de trazo a su valor original
  context.strokeStyle = "#1a3d75"; // Cambia "black" al color deseado
 
  context.moveTo(80, 15);
  context.lineTo(80, 300);
  context.moveTo(80,15);
  context.lineTo(150, 15);
  context.moveTo(150, 15);
  context.lineTo(150, 26);

  context.lineWidth = 5;
  context.stroke();

}

//INICIO DEL JUEGO
function iniciar(event) {
  //Deshabilitamos el botón de reinicio.
  btnReiniciar.disabled = true;
  intentosJuego.innerHTML = totalIntentos;
  


  cantidadErrores = 0;
  cantAciertos = 0;
  //Obtenemos el elemento p en donde escribiremos los espacios de palabra
  const parrafo = id('palabra_a_adivinar');
  //Vacíamos el espacio antes de saber la palabra.
  parrafo.innerHTML = '';

  //Obtenemos la cantidad de palabras que tenemos en el vector.
  const cant_palabras = palabras.length;
  //Con el método que tenemos en funciones obtenemos el número random.
  const valor_al_azar = obtener_random(0, cant_palabras);
  //La palabra a adivinar sera escogido por el valor alazar obtenido.
  palabraAdivinar = palabras[valor_al_azar];
  console.log(palabraAdivinar);

  //Obtenemos la cantidad de letras de la palabra adivinar.
  const cant_letras = palabraAdivinar.length;

  //Habilitaremos cada botón con este for.

  for (let i = 0; i < btn_letras.length; i++) {
    btn_letras[i].disabled = false;


  }

  //Insertamos los espacios según la cantidad de letras.
  for (let i = 0; i < cant_letras; i++) {
    const span = document.createElement('span');
    parrafo.appendChild(span);
  }


}



//For constante que permite evaluar e integrar los clicks con su función.
for (let i = 0; i < btn_letras.length; i++) {
  btn_letras[i].addEventListener('click', click_letras);

}

//Función accionada al realizar el click
function click_letras(event) {
  
  const espacios = document.querySelectorAll('#palabra_a_adivinar span');

  const button = event.target; // Cuál de todas las letras llamó a la función
  //Deshabilitamos el botón ya utilizado.
  button.disabled = true;
  const letra = button.innerHTML;
  //Mostramos en consola cual valor contiene el botón.
  console.log(letra);
  const palabra = palabraAdivinar.toUpperCase();

  let acerto = false;


  for (let i = 0; i < palabra.length; i++) {
    if (letra == palabra[i]) {

      // la variable i es la posición de la letra en la palabra.
      // que coincide con el span al que tenemos que mostrarle esta letra.
      // Si coincide aumentaremos el valor de aciertos y sustituimos el span por la letra.

      espacios[i].innerHTML = letra;
      cantAciertos++;
      acerto = true;
    }
  }

  //Esta es la función con la que graficamos al muñeco.
  function drawHangman(errors) {
    

    

    if (errors == 1) {
      // Restaurar el color de trazo a su valor original
      context.strokeStyle = "black"; // Cambia "black" al color que se desea.
      // Draw head
      context.beginPath();
      context.arc(150, 50, 25, 0, Math.PI * 2);
      context.lineWidth = 3;
      context.stroke();
    }

    if (errors == 2) {
      // Restaurar el color de trazo a su valor original
      context.strokeStyle = "black"; // Cambia "black" que se desea.
      // Draw body
      context.moveTo(150, 75);
      context.lineTo(150, 150);
      context.lineWidth = 3;
      context.stroke();
    }

    if (errors >= 3) {
      // Restaurar el color de trazo a su valor original
      context.strokeStyle = "black"; // Cambia "black" que se desea.
      // Draw left arm
      context.moveTo(150, 85);
      context.lineTo(100, 120);
      context.lineWidth = 3;
      context.stroke();
    }

    if (errors >= 4) {
      // Restaurar el color de trazo a su valor original
      context.strokeStyle = "black"; // Cambia "black" que se desea.
      // Draw right arm
      context.moveTo(150, 85);
      context.lineTo(200, 120);
      context.lineWidth = 3;
      context.stroke();
    }

    if (errors >= 5) {
      // Restaurar el color de trazo a su valor original
      context.strokeStyle = "black"; // Cambia "black" que se desea.
      // Draw left leg
      context.moveTo(150, 150);
      context.lineTo(125, 220);
      context.lineWidth = 3;
      context.stroke();
    }

    if (errors >= 6) {
      // Restaurar el color de trazo a su valor original
      context.strokeStyle = "black"; // Cambia "black" al color deseado
      // Draw right leg
      context.moveTo(150, 150);
      context.lineTo(175, 220);
      context.lineWidth = 3;
      context.stroke();
    }

    if (errors >= 7) {
      context.strokeStyle = "red";

      context.moveTo(150, 75);
      context.lineTo(300, 35);
      context.lineWidth = 3;
      context.stroke();

      
    }
  }

  //Si los aciertos son falsos, es decir, no hay aciertos se suma la cantidad de errores.
  if (acerto == false) {
    cantidadErrores++;
   
   //Reducimos la cantidad de intentos en el párrafo. 
    totalIntentos--;
    intentosJuego.innerHTML = totalIntentos;


    drawHangman(cantidadErrores);
  }

  if (cantidadErrores == 7) {
    id('resultado').innerHTML = "Perdiste, la palabra era: " + palabraAdivinar;
    btnReiniciar.disabled = false;
    game_over();
  } else if (cantAciertos == palabraAdivinar.length) {
    id('resultado').innerHTML = "¡¡Ganaste!!";
    btnReiniciar.disabled = false;
    game_over();
  }

  

  function game_over() {
    for (let i = 0; i < btn_letras.length; i++) {
      btn_letras[i].disabled = true;


    }
  }

 // btn.disabled = false;



}